# うさうさ研修工房 成果物まとめ

| フォルダ | 中身 |
|---|---|
| 01_skills | Skill2種：usausa-dev-env-ppt-redesign（環境構築PPTの作成・改修）、usausa-brand-stamp-kit（ブランド・PC環境に合わせたスタンプ・アイコン・図形） |
| 02_zenn-and-docs | Zenn記事（zenn-dev-env-ppt-skill.md、published: false）、スキル説明.md |
| 03_dify-course | 「Dify 0から入門」Udemy講座：構成案（全10章）、第1章（受講生用PPT・講師用PPT・講師用Word）、作成スクリプト |

## 第2章以降の作り方
build-scripts/content.js に章ごとの内容（8ブロック）を書き、build_pptx.js（受講生用／講師用 `notes`）と build_docx.js で生成します。
`node build_pptx.js out.pptx` ／ `node build_pptx.js out.pptx notes` ／ `node build_docx.js out.docx`

## 未確認・注意
- Skillの色・企業名は仮値。Mac・旧Office等は実機未確認
- Difyの機能名・画面・料金は撮影時に公式で確認（[要確認]）
- 第2〜10章の資料は未作成（第1章で台本の量と文体を確認してから進める）
