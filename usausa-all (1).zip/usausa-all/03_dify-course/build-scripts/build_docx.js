const fs=require("fs");
const {Document,Packer,Paragraph,TextRun,Table,TableRow,TableCell,WidthType,ShadingType,HeadingLevel,LevelFormat,AlignmentType,ExternalHyperlink}=require("docx");
const C=require("./content.js");
const F={ascii:"Arial",hAnsi:"Arial",eastAsia:"Yu Gothic",cs:"Arial"};
const PL="3B1A38",RO="C2456B",CARD="F8F0F3";
const r=(t,o={})=>new TextRun({text:t,font:F,...o});
const p=(t,o={})=>new Paragraph({spacing:{after:100},children:[r(t,o.run||{})],...o.para});
const h=(t,l)=>new Paragraph({heading:l,spacing:{before:l==HeadingLevel.HEADING_1?300:200,after:120},children:[r(t,{bold:true,color:l==HeadingLevel.HEADING_1?PL:RO,size:l==HeadingLevel.HEADING_1?32:26})]});
const b=t=>new Paragraph({numbering:{reference:"b",level:0},spacing:{after:60},children:[r(t)]});
const cell=(t,w,hd)=>new TableCell({width:{size:w,type:WidthType.DXA},shading:{type:ShadingType.CLEAR,fill:hd?PL:CARD,color:"auto"},margins:{top:80,bottom:80,left:120,right:120},children:String(t).split("\n").map(x=>new Paragraph({children:[r(x,{bold:hd,color:hd?"FFFFFF":"2E1B2C",size:20})]}))});
const tbl=(rows,cw)=>new Table({width:{size:cw.reduce((a,c)=>a+c,0),type:WidthType.DXA},columnWidths:cw,rows:rows.map((row,i)=>new TableRow({children:row.map((c,j)=>cell(c,cw[j],i==0))}))});

// 各ブロックの「スライド内容」を、共通データから箇条書き用に取り出す
function content(x){
  if(x.bullets) return x.bullets;
  if(x.goal) return ["ゴール："+x.goal.join("／"),"地図："+x.map.join("／")];
  if(x.three) return x.three;
  if(x.cards) return [...x.cards.map(c=>c[0]+"："+c[1]),...x.modes.map(m=>"使い方・"+m[0]+"："+m[1])];
  if(x.flow) return ["流れ："+x.flow.join(" → "),x.inside];
  if(x.work) return [...x.work.map((w,i)=>`${i+1}. ${w}`),x.ex];
  if(x.qa) return x.qa.map(q=>"Q. "+q[0]+" → "+q[1]);
  if(x.next) return [x.next];
  return [];
}
const B=C.blocks;
const ch=[
 h(C.chapter+"（講師用資料）",HeadingLevel.HEADING_1),
 p("講座："+C.course),
 tbl([["項目","内容"],["章のゴール","Difyが何で何ができるかを説明でき、自分が作りたいアプリを1つ決める"],["難易度","★（ウォーミングアップ）"],["対象","DXエンジニア（LLMアプリ開発は未経験でもよい）"],["題材","社内ヘルプデスク（講義用の架空の例）"],["時間（案）",C.total]],[2200,7400]),
 h("1. 進行表",HeadingLevel.HEADING_2),
 tbl([["ブロック","時間","スライドの見出し","リズム"],...B.map(x=>[x.no,x.min,x.title,x.rhythm])],[1300,800,4400,3100]),
 h("2. ブロック別の内容と台本",HeadingLevel.HEADING_2)
];
B.forEach(x=>{
  ch.push(h(`${x.no}（${x.min}）`,HeadingLevel.HEADING_2));
  ch.push(p("スライドの見出し："+x.title,{run:{bold:true}}));
  ch.push(p("スライドの内容：",{run:{bold:true}}));
  content(x).forEach(t=>ch.push(b(t)));
  ch.push(p("台本：",{run:{bold:true}}));
  ch.push(p(x.script));
  ch.push(p("声かけ："+x.call));
  ch.push(p("リズム："+x.rhythm));
  ch.push(p("注意："+x.note));
});
ch.push(h("3. 出典",HeadingLevel.HEADING_2));
C.sources.forEach(s=>ch.push(new Paragraph({numbering:{reference:"b",level:0},spacing:{after:60},children:[r(s[0]+"："),new ExternalHyperlink({link:s[1],children:[r(s[1],{color:RO,underline:{}})]})]})));
ch.push(h("4. 確認していない点・注意",HeadingLevel.HEADING_2));
C.cautions.forEach(t=>ch.push(b(t)));
const doc=new Document({styles:{default:{document:{run:{font:F,size:22}}}},numbering:{config:[{reference:"b",levels:[{level:0,format:LevelFormat.BULLET,text:"•",alignment:AlignmentType.LEFT,style:{paragraph:{indent:{left:720,hanging:360}}}}]}]},sections:[{properties:{page:{size:{width:11906,height:16838},margin:{top:1134,bottom:1134,left:1134,right:1134}}},children:ch}]});
Packer.toBuffer(doc).then(buf=>{fs.writeFileSync(process.argv[2],buf);console.log("ok");});
