const P=require("pptxgenjs");const p=new P();p.layout="LAYOUT_WIDE";
const PL="3B1A38",RO="C2456B",GO="C9932F",INK="2E1B2C",SUB="6E5A6A",CARD="F8F0F3",W="FFFFFF",DK="241021",F="Yu Gothic";
const T=(s,t,o)=>s.addText(t,{isTextBox:true,margin:0,fontFace:F,color:INK,...o});
function sl(tag,title,dark){const s=p.addSlide();s.background={color:dark?DK:W};
 if(tag)T(s,tag,{x:.6,y:.35,w:9,h:.3,fontSize:12,bold:true,color:dark?GO:RO});
 T(s,title,{x:.6,y:.7,w:12.1,h:.9,fontSize:title.length>30?24:28,bold:true,color:dark?W:PL,valign:"top"});return s;}
function box(s,x,y,w,h,head,body,col,fs){
 s.addShape("roundRect",{x,y,w,h,rectRadius:.08,fill:{color:CARD},line:{color:"E4D3DA",width:1}});
 T(s,head,{x:x+.25,y:y+.2,w:w-.5,h:.4,fontSize:15,bold:true,color:col||RO});
 T(s,body,{x:x+.25,y:y+.75,w:w-.5,h:h-.95,fontSize:fs||16,valign:"top",paraSpaceAfter:5});}
const CH=[
["Difyって何？ゴールを先に見よう",1,"楽","Difyが何で、何ができるかを説明できる","完成デモを見る\nDifyの全体像（チャット・ナレッジ・ワークフロー・API）\n作りたいアプリを1つ決める","作りたいアプリ1つ（誰の・困りごと・欲しい答え）"],
["Windowsに開発環境をつくる",2,"苦","Ubuntu（WSL 2）が起動し、VSCodeからつながる","WSL 2とUbuntuの導入\nVSCodeのインストール\nVSCodeのWSL拡張でUbuntuに接続","Ubuntuのターミナルが開く／VSCodeから接続できる\n※作業フォルダはUbuntuのホーム（~）。Windows側（/mnt/c）に置かない"],
["Docker超入門（コマンドを5つだけ）",2,"苦→楽","Dockerとは何かを一言で言え、基本コマンドを実行できる","コンテナ＝アプリの箱、イメージ＝設計図\nversion確認 → hello-world → ps\nDifyが使うcomposeコマンドの予習","docker run hello-world が成功する\n※Docker Desktopの会社PCでの利用条件は要確認"],
["Difyを自分のPCで起動する",3,"楽（山場）","http://localhost/install でDifyの画面が開く","Difyのソースを取得\ncd dify/docker\ndocker compose up -d\ndocker compose ps で各コンテナを確認","Difyの初期設定画面が開く\n※つまずき：ポート使用中／メモリ不足／Exited"],
["初期設定とモデルの登録",2,"楽","管理者アカウントを作り、AIモデルを登録して動かす","初期設定画面\nモデルプロバイダの設定\nAPIキーの扱い方","モデルが動作確認できる\n※APIキーは他人に見せない・資料に書かない"],
["最初のチャットアプリ",2,"楽","プロンプトを書き、チャットアプリを動かす","社内ヘルプデスクの一次回答を題材に\nプロンプトの3要素：役割・条件・出力形式","動くチャットアプリ1本"],
["ナレッジ（RAG）で社内文書に答えさせる",3,"苦","PDF／テキストを登録し、その内容に基づいて答えるアプリを作る","RAGの仕組み：資料→分割→検索→回答\nダミー社内規程を登録\n回答の根拠を確認","文書に答えるアプリ\n※機密文書の保存先・外部モデルへ送られる内容は要確認"],
["ワークフローで業務を自動化する",4,"苦","入力→判定（条件分岐）→回答→出力の流れを作る","変数とノードのつなぎ方\n問い合わせの種類で振り分け\n完成したフローを動かす","条件分岐つきの業務フロー\n※ここが一番の難所"],
["運用の基本（止める・直す・守る）",3,"苦→楽","停止・再起動・ログ確認ができ、自力で調べられる","docker compose ps／down／up -d／logs\nわざと止めて再起動し、データが残ることを確認","ログの見方と復旧手順\n※更新・バックアップの公式手順は要確認"],
["総合演習：DX業務アプリを作る",4,"楽（達成）","自分の業務で使えるアプリを1本作り、発表する","第1章で決めたアプリを作る\n例：問い合わせ対応・議事録要約・規程検索\nセルフチェックして発表","自分の業務アプリ1本\n観点：目的／入出力／間違い時の対応／機密の扱い"]];
let s;
// 1 表紙
s=sl("Udemy講座デッキ","【Dify 0から入門】DXエンジニアのための生成AIアプリ開発",true);
T(s,"Windows × Ubuntu（WSL 2）× VSCode × Docker ／ 全10章",{x:.6,y:2.4,w:12.1,h:.6,fontSize:20,color:"F2E6EB"});
T(s,"世界一エンジニア ／ Difyの先生",{x:.6,y:3.4,w:12.1,h:.5,fontSize:18,bold:true,color:GO});
// 2 概要
s=sl("講座概要","この講座で目指すこと");
box(s,.6,1.8,3.9,4.4,"対象","DXエンジニア（業務改善・社内システム担当）\nLLMアプリ開発は未経験でOK\nコマンドも初めてでOK",PL);
box(s,4.7,1.8,3.9,4.4,"ゴール","自分のPCにDifyを構築し、チャットアプリ・ナレッジ（RAG）・ワークフローを自力で作って動かせる",RO);
box(s,8.8,1.8,3.9,4.4,"環境・形式","Windows ＋ WSL 2（Ubuntu）＋ VSCode ＋ Docker Desktop\n1章＝解説動画＋ハンズオン＋確認クイズ",GO);
// 3 スロープ
s=sl("全体設計","10章のスロープ：難易度と、楽・苦のリズム");
CH.forEach((c,i)=>{const x=.8+i*1.17,hh=c[1]*.8,y=5.2-hh,col=c[2].startsWith("苦")?PL:RO;
 s.addShape("rect",{x,y,w:.95,h:hh,fill:{color:col},line:{type:"none"}});
 T(s,String(i+1),{x,y:5.25,w:.95,h:.35,fontSize:16,bold:true,align:"center",color:PL});
 T(s,c[2],{x,y:5.6,w:.95,h:.5,fontSize:11,align:"center",color:SUB,valign:"top"});});
T(s,"棒の高さ＝難易度。rose＝楽／plum＝苦。苦しい章の直後に楽しい章（成功体験）を置く。",{x:.8,y:6.4,w:11.8,h:.4,fontSize:14,color:SUB});
// 4-13 各章
CH.forEach((c,i)=>{s=sl(`第${i+1}章 ／ 難易度 ${"★".repeat(c[1])}${"☆".repeat(5-c[1])} ／ ${c[2]}`,`第${i+1}章　${c[0]}`);
 box(s,.6,1.9,3.6,4.3,"章のゴール",c[3],PL);
 box(s,4.4,1.9,4.2,4.3,"やること",c[4],RO,15);
 box(s,8.8,1.9,3.9,4.3,"成果物・注意",c[5],GO,14);});
// 14 Dockerコマンド
s=sl("付録","Dockerコマンド一覧（第3・4・9章）");
const rows=[["コマンド","意味","成功の目印"],["docker --version","Dockerの確認","バージョン表示"],["docker compose version","Composeの確認（Difyは2.24.0以上）","バージョン表示"],["docker run hello-world","動作確認","成功メッセージ"],["docker ps","動作中コンテナの一覧","一覧が出る（空でも可）"],["docker compose up -d","まとめて起動（dify/docker で実行）","各コンテナが起動"],["docker compose ps","状態確認","各コンテナが表示される"],["docker compose down","停止","コンテナが停止"],["docker compose logs","ログ確認","ログが表示される"]];
s.addTable(rows.map((r,i)=>r.map(t=>({text:t,options:{fontFace:F,fontSize:14,bold:i==0,color:i==0?W:INK,fill:{color:i==0?PL:(i%2?CARD:W)},valign:"middle"}}))),{x:.6,y:1.8,w:12.1,colW:[3.8,5.2,3.1],rowH:.5,border:{type:"solid",color:"E4D3DA",pt:1}});
// 15 起動の流れ
s=sl("付録","Dify起動の流れ（第4章）");
["Ubuntuで作業場所（~）へ","Difyのソースを取得（GitHub）","cd dify/docker","docker compose up -d","docker compose ps で確認","ブラウザで localhost/install"].forEach((t,i)=>{const x=.6+(i%3)*4.1,y=1.9+Math.floor(i/3)*2.2;
 s.addShape("roundRect",{x,y,w:3.8,h:1.8,rectRadius:.08,fill:{color:i%2?RO:PL},line:{type:"none"}});
 T(s,`${i+1}　${t}`,{x:x+.2,y,w:3.4,h:1.8,fontSize:18,bold:true,color:W,valign:"middle"});});
T(s,"出典：Dify公式ドキュメント「Deploy Dify with Docker Compose」。Windowsは WSL 2 ＋ Docker Desktop（Compose 2.24.0以上）。",{x:.6,y:6.5,w:12.1,h:.4,fontSize:12,color:SUB});
// 16 要確認
s=sl("撮影前チェック","撮影前に確認する項目［要確認］");
box(s,.6,1.8,6.0,4.4,"環境・手順","1. Windowsの版／WSL 2・Ubuntu導入の画面\n2. Docker Desktopの利用条件（会社PC）\n3. Windowsの推奨スペック\n4. .env の作成手順（最新README）",PL);
box(s,6.8,1.8,5.9,4.4,"画面・運用・規約","5. モデル登録・アプリ作成のUI名称\n6. クラウド版の無料枠・費用が出る箇所\n7. 機密データの保存先と外部モデルへの送信内容\n8. 更新・バックアップの公式手順",RO);
// 17 まとめ
s=sl("まとめ","全10章で、自分のPCにDifyを建て、業務アプリを作る",true);
T(s,"第1章：ゴールを決める → 第2〜4章：環境とDify起動 → 第5〜8章：作る → 第9〜10章：運用と総合演習\nDifyの画面・版は更新されるため、各章の冒頭に収録日と使用バージョンを明記します。",{x:.6,y:2.3,w:12.1,h:1.6,fontSize:20,color:"F2E6EB",paraSpaceAfter:12,valign:"top"});
p.writeFile({fileName:process.argv[2]}).then(()=>console.log("ok"));
