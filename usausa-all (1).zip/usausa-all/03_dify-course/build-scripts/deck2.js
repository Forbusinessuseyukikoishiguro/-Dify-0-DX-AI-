const P=require("pptxgenjs");const p=new P();p.layout="LAYOUT_WIDE";
const PL="3B1A38",RO="C2456B",GO="C9932F",INK="2E1B2C",SUB="6E5A6A",CARD="F8F0F3",W="FFFFFF",DK="241021",F="Yu Gothic";
const T=(s,t,o)=>s.addText(t,{isTextBox:true,margin:0,fontFace:F,color:INK,...o});
function sl(tag,title,dark){const s=p.addSlide();s.background={color:dark?DK:W};
 if(tag)T(s,tag,{x:.6,y:.35,w:9,h:.3,fontSize:12,bold:true,color:dark?GO:RO});
 T(s,title,{x:.6,y:.7,w:12.1,h:.9,fontSize:title.length>30?24:28,bold:true,color:dark?W:PL,valign:"top"});return s;}
function box(s,x,y,w,h,head,body,col,fs){
 s.addShape("roundRect",{x,y,w,h,rectRadius:.08,fill:{color:CARD},line:{color:"E4D3DA",width:1}});
 T(s,head,{x:x+.25,y:y+.2,w:w-.5,h:.4,fontSize:15,bold:true,color:col||RO});
 T(s,body,{x:x+.25,y:y+.75,w:w-.5,h:h-.95,fontSize:fs||16,valign:"top",paraSpaceAfter:5});}
const CH=[
["エラー対応の考え方：失敗を前提に設計する",2,"楽","「どこで・何が・なぜ」の切り分け順を言える","画面のエラー → 実行履歴 → ノード → コンテナ、の順に切り分ける\n入門編の業務アプリを題材に、わざと壊して観察する","切り分けチェックリスト（1枚）\n※エラー文だけで原因を決めつけない"],
["デバッグ道具を使い倒す",3,"苦","実行履歴・単体実行・変数確認で、失敗箇所を特定できる","Run History：Result／Detail／Tracing（実行順・所要時間・データの流れ）\nノードの「Last run」で直近の入出力を確認\nSingle Node（単体実行）／Variable Inspector","失敗したフローの原因ノードを特定\n※公開後のユーザー実行は、Logsで確認する"],
["ワークフローのエラー処理を設計する",4,"苦","Default value／Fail branch／Retry on Failure を使い分けられる","既定は、ノード失敗でフロー全体が停止\nDefault value：代わりの値で続行（型は出力型と一致）\nFail branch：失敗時の別ルートへ（オレンジ表示）\nRetry on Failure：最大回数と間隔を設定\nerror_type・error_message を後続ノードで使う","失敗しても止まらないフロー\n※LLM・HTTP・Code・Toolノードが標準で対応。Iterationは専用のモードあり"],
["エラーの種類を読み解く",3,"苦→楽","エラー種別から、直す場所の見当をつけられる","公式の「Error Types」を読み、自分のアプリで出たエラーを分類する\n分類表を作り、チームで共有する","自分たちのエラー分類表\n※各エラー種別の中身は撮影時に公式で確認 [要確認]"],
["セルフホストの障害を切り分ける",4,"苦","コンテナの状態とログから、環境側の問題を切り分けられる","docker compose ps（状態）→ docker compose logs（ログ）\n再起動の判断と、データの保全\n公式Troubleshooting（Common Issues／Docker Issues／Third-Party Integrations／Storage & Migration）を読む","障害切り分けの手順書\n※データを消す操作の前に、必ずバックアップを確認"],
["外部連携・API開発のエラー対応",4,"苦","HTTP連携の失敗を想定し、代替ルートを設計できる","HTTPリクエストノードの失敗を、Fail branchで受ける\n公式の例：主APIが失敗したら、予備APIを呼ぶ\nタイムアウト・認証・入力不正を分けて考える","外部連携つきの業務フロー\n※認証情報（APIキー）は資料・ログに出さない"],
["品質と運用：変更を安全に反映する",3,"楽","ログ監視とバージョン管理で、変更を安全に運用できる","公開後の利用状況をLogsで確認\nVersion Controlで変更を管理\n更新・移行の前に、保存先とバックアップを確認","変更・更新の運用ルール\n※更新手順は最新の公式で確認 [要確認]"],
["総合演習：壊れても止まらない業務フロー",4,"楽（達成）","故意に障害を起こし、検知・復旧・再発防止まで実演する","入門編のアプリに、リトライ・Fail branch・通知を追加\nわざと失敗させ、実行履歴で原因を特定\n復旧手順書と再発防止策を書く","障害対応の振り返りシート\n観点：検知／切り分け／復旧／再発防止"]];
let s;
s=sl("Udemy講座デッキ（続編）","【Dify 中堅向け】エラー対応・開発編",true);
T(s,"壊れても止まらない、壊れても直せる業務AIアプリ",{x:.6,y:1.6,w:12.1,h:.6,fontSize:22,bold:true,color:W});
T(s,"入門編の続編 ／ 全8章 ／ Windows × Ubuntu（WSL 2）× Docker",{x:.6,y:2.4,w:12.1,h:.6,fontSize:20,color:"F2E6EB"});
T(s,"世界一エンジニア ／ Difyの先生",{x:.6,y:3.4,w:12.1,h:.5,fontSize:18,bold:true,color:GO});
s=sl("講座概要","この講座で目指すこと");
box(s,.6,1.8,3.9,4.4,"対象・前提","DXエンジニア（中堅）\n入門編を修了、または同等の経験\nDifyを自分のPCで起動し、ワークフローを作った経験",PL);
box(s,4.7,1.8,3.9,4.4,"ゴール","Difyアプリで起きるエラーを、自力で切り分け・復旧でき、失敗しても止まらないフローを設計できる",RO);
box(s,8.8,1.8,3.9,4.4,"形式","1章＝解説動画＋ハンズオン＋確認クイズ\n題材：入門編の社内ヘルプデスク（架空の例）",GO);
s=sl("全体設計","8章のスロープ：難易度と、楽・苦のリズム");
CH.forEach((c,i)=>{const x=.9+i*1.45,hh=c[1]*.8,y=5.2-hh,col=c[2].startsWith("苦")?PL:RO;
 s.addShape("rect",{x,y,w:1.15,h:hh,fill:{color:col},line:{type:"none"}});
 T(s,String(i+1),{x,y:5.25,w:1.15,h:.35,fontSize:16,bold:true,align:"center",color:PL});
 T(s,c[2],{x,y:5.6,w:1.15,h:.5,fontSize:11,align:"center",color:SUB,valign:"top"});});
T(s,"棒の高さ＝難易度。rose＝楽／plum＝苦。苦しい章の直後に、楽しい章（成功体験）を置く。",{x:.9,y:6.4,w:11.8,h:.4,fontSize:14,color:SUB});
CH.forEach((c,i)=>{s=sl(`第${i+1}章 ／ 難易度 ${"★".repeat(c[1])}${"☆".repeat(5-c[1])} ／ ${c[2]}`,`第${i+1}章　${c[0]}`);
 box(s,.6,1.9,3.6,4.3,"章のゴール",c[3],PL);
 box(s,4.4,1.9,4.2,4.3,"やること",c[4],RO,14);
 box(s,8.8,1.9,3.9,4.3,"成果物・注意",c[5],GO,14);});
s=sl("付録","ワークフローのエラー処理：選び方");
const rows=[["方式","動き","使いどころ"],["既定（未設定）","ノードが失敗すると、フロー全体が停止","原因をすぐ知りたい開発中"],["Default value","代わりの値で続行（型は出力型と一致）","失敗しても、仮の値で進めてよい処理"],["Fail branch","失敗時の別ルート（オレンジ）を実行","予備の処理・通知・代替APIに切り替える"],["Retry on Failure","最大回数と間隔を設定して再実行","一時的な失敗（通信の揺れなど）"]];
s.addTable(rows.map((r,i)=>r.map(t=>({text:t,options:{fontFace:F,fontSize:15,bold:i==0,color:i==0?W:INK,fill:{color:i==0?PL:(i%2?CARD:W)},valign:"middle"}}))),{x:.6,y:1.8,w:12.1,colW:[3.0,5.0,4.1],rowH:.7,border:{type:"solid",color:"E4D3DA",pt:1}});
T(s,"後続ノードで error_type と error_message を使えます（Default value／Fail branch）。LLM・HTTP・Code・Toolノードが対応。",{x:.6,y:5.8,w:12.1,h:.5,fontSize:14,color:SUB});
s=sl("付録","障害の切り分け順（画面 → 実行履歴 → コンテナ）");
["画面のエラー文を読む","Run History（Result／Detail／Tracing）","ノードの Last run／単体実行","Variable Inspectorで変数を確認","docker compose ps で状態確認","docker compose logs でログ確認","公式Troubleshootingを読む"].forEach((t,i)=>{const x=.6+(i%4)*3.1,y=1.9+Math.floor(i/4)*2.2;
 s.addShape("roundRect",{x,y,w:2.9,h:1.8,rectRadius:.08,fill:{color:i<4?PL:RO},line:{type:"none"}});
 T(s,`${i+1}　${t}`,{x:x+.2,y,w:2.5,h:1.8,fontSize:16,bold:true,color:W,valign:"middle"});});
T(s,"上の4つ＝Difyの画面で確認（plum）／下の3つ＝環境側（rose）。画面で分からなければ環境へ。",{x:.6,y:6.4,w:12.1,h:.4,fontSize:13,color:SUB});
s=sl("付録","障害対応で使うコマンド（dify/docker で実行）");
const r2=[["コマンド","意味","注意"],["docker compose ps","各コンテナの状態","Exitedや再起動の繰り返しを確認"],["docker compose logs","ログの確認","サービス名は ps の表示で確認"],["docker compose down","停止","データ（ボリューム）の扱いは公式で確認"],["docker compose up -d","起動","変更後の再起動にも使う"]];
s.addTable(r2.map((r,i)=>r.map(t=>({text:t,options:{fontFace:F,fontSize:15,bold:i==0,color:i==0?W:INK,fill:{color:i==0?PL:(i%2?CARD:W)},valign:"middle"}}))),{x:.6,y:1.8,w:12.1,colW:[3.6,3.8,4.7],rowH:.7,border:{type:"solid",color:"E4D3DA",pt:1}});
s=sl("撮影前チェック","撮影前に確認する項目［要確認］");
box(s,.6,1.8,6.0,4.4,"機能・画面","1. エラー処理の設定画面の名称（撮影時の版）\n2. Error Typesの各種別の内容\n3. Retry on Failureの設定項目の最新仕様\n4. Iterationのエラー処理モードの選択肢",PL);
box(s,6.8,1.8,5.9,4.4,"運用・環境","5. Troubleshooting 4ページの具体的な内容\n6. 更新・移行・バックアップの公式手順\n7. データを消す操作の影響範囲\n8. 外部API連携の認証・タイムアウト設定",RO);
s=sl("出典・まとめ","まとめ：壊れても止まらない、壊れても直せるアプリへ",true);
T(s,"設計（Default value／Fail branch／Retry）＋ 調査（Run History／単体実行／変数確認）＋ 環境（ps／logs）の3本柱で対応します。",{x:.6,y:2.2,w:12.1,h:1.2,fontSize:20,color:"F2E6EB",valign:"top"});
const srcs=[["Dify公式：Predefined Error Handling Logic","https://docs.dify.ai/en/self-host/use-dify/build/predefined-error-handling-logic.md"],["Dify公式：Run History","https://docs.dify.ai/en/self-host/use-dify/debug/history-and-logs.md"],["Dify公式：Self-Host 目次（Troubleshooting／Debug）","https://docs.dify.ai/_llms/en/self-host.md"]];
s.addText(srcs.flatMap((x,i)=>[{text:(i?"":"出典：")+x[0]+"  ",options:{color:W,bold:true}},{text:x[1],options:{color:GO,hyperlink:{url:x[1]},breakLine:i<2}}]),{isTextBox:true,margin:0,fontFace:F,x:.6,y:5.6,w:12.1,h:1.0,fontSize:10.5,valign:"top"});
p.writeFile({fileName:process.argv[2]}).then(()=>console.log("ok"));
