const P = require("pptxgenjs");
const C = require("./content.js");
const withNotes = process.argv[3] === "notes";
const out = process.argv[2];
const p = new P(); p.layout = "LAYOUT_WIDE";
const PL="3B1A38",RO="C2456B",GO="C9932F",INK="2E1B2C",SUB="6E5A6A",CARD="F8F0F3",W="FFFFFF",DK="241021",F="Yu Gothic";
const T=(s,t,o)=>s.addText(t,{isTextBox:true,margin:0,fontFace:F,color:INK,...o});
function sl(b,dark){const s=p.addSlide();s.background={color:dark?DK:W};
  T(s,`第1章 ${b.no}（${b.min}）`,{x:.6,y:.35,w:9,h:.3,fontSize:12,bold:true,color:dark?GO:RO});
  T(s,b.title,{x:.6,y:.7,w:12.1,h:.9,fontSize:b.title.length>30?24:28,bold:true,color:dark?W:PL,valign:"top"});
  if(withNotes) s.addNotes(`【時間】${b.min}\n【台本】${b.script}\n【声かけ】${b.call}\n【リズム】${b.rhythm}\n【注意】${b.note}`);
  return s;}
function box(s,x,y,w,h,head,body,col,dark,fs){
  s.addShape("roundRect",{x,y,w,h,rectRadius:.08,fill:{color:dark?"3B1A38":CARD},line:{color:"E4D3DA",width:1}});
  T(s,head,{x:x+.25,y:y+.2,w:w-.5,h:.4,fontSize:15,bold:true,color:col||RO});
  T(s,body,{x:x+.25,y:y+.75,w:w-.5,h:h-.95,fontSize:fs||17,valign:"top",paraSpaceAfter:5,color:dark?"F2E6EB":INK});}
const B=C.blocks;
let s;
// ① 導入
s=sl(B[0],true);
T(s,B[0].bullets.map(x=>"・"+x).join("\n"),{x:.6,y:2.0,w:12.1,h:2.6,fontSize:20,color:"F2E6EB",paraSpaceAfter:12,valign:"top"});
T(s,"この講座では、Difyで「生成AIアプリ」を作る最初の一歩を学びます",{x:.6,y:5.2,w:12.1,h:.6,fontSize:18,bold:true,color:GO});
// ② 概要
s=sl(B[1]);
box(s,.6,1.8,5.0,4.6,"この章のゴール",B[1].goal.join("\n\n"),RO);
T(s,"全10章の地図",{x:6.0,y:1.85,w:6.7,h:.4,fontSize:15,bold:true,color:PL});
T(s,B[1].map.join("\n"),{x:6.0,y:2.4,w:6.7,h:4.0,fontSize:16,paraSpaceAfter:3,valign:"top"});
// ③ 要点
s=sl(B[2]);
B[2].three.forEach((t,i)=>box(s,.6+i*4.1,2.0,3.9,3.4,String(i+1),t,i%2?RO:PL));
// ④ 説明
s=sl(B[3]);
T(s,"Difyでできること",{x:.6,y:1.6,w:6,h:.35,fontSize:15,bold:true,color:PL});
B[3].cards.forEach((c,i)=>box(s,.6+i*3.05,2.0,2.9,2.0,c[0],c[1],[PL,RO,GO,PL][i],false,13));
T(s,"2つの使い方",{x:.6,y:4.3,w:6,h:.35,fontSize:15,bold:true,color:PL});
B[3].modes.forEach((m,i)=>box(s,.6+i*6.2,4.7,5.9,1.7,m[0],m[1],i?RO:PL,false,15));
T(s,"機能の名称は、撮影時のDifyの画面で確認します。",{x:.6,y:6.65,w:12.1,h:.3,fontSize:11,color:SUB});
// ⑤ 図解
s=sl(B[4]);
const cols=[PL,RO,GO,PL];
B[4].flow.forEach((t,i)=>{const x=.9+i*3.1;
  s.addShape("roundRect",{x,y:2.4,w:2.4,h:1.6,rectRadius:.08,fill:{color:cols[i]},line:{type:"none"}});
  T(s,t,{x,y:2.4,w:2.4,h:1.6,fontSize:18,bold:true,color:W,align:"center",valign:"middle"});
  if(i<3)T(s,"→",{x:x+2.45,y:2.8,w:.6,h:.8,fontSize:30,bold:true,color:RO,align:"center"});});
T(s,B[4].inside,{x:4.0,y:4.2,w:2.4,h:.8,fontSize:12,color:SUB,align:"center",valign:"top"});
T(s,"この講座では、真ん中の「Difyアプリ」を作ります",{x:.9,y:5.4,w:11.5,h:.6,fontSize:18,bold:true,color:RO});
T(s,"※概念を簡略化した図です。詳しい構成は第4章以降で見ます。",{x:.9,y:6.2,w:11.5,h:.3,fontSize:11,color:SUB});
// ⑥ 実践
s=sl(B[5]);
box(s,.6,1.9,6.0,4.4,"やってみよう（個人ワーク3分＋共有2分）",B[5].work.map((x,i)=>`${i+1}. ${x}`).join("\n\n"),RO);
box(s,6.8,1.9,5.9,4.4,"例",B[5].ex+"\n\n※小さく始めてOK。1つの質問に答えるだけで十分です\n※決めたものは、第10章の総合演習で使います",PL);
// ⑦ 質問
s=sl(B[6]);
B[6].qa.forEach((q,i)=>box(s,.6+i*4.1,1.9,3.9,4.0,"Q. "+q[0],q[1],[RO,PL,GO][i]));
// ⑧ 対応
s=sl(B[7],true);
T(s,B[7].next,{x:.6,y:2.2,w:12.1,h:.8,fontSize:20,color:"F2E6EB"});
s.addText(C.sources.flatMap((x,i)=>[
  {text:(i?"":"出典：")+x[0]+"  ",options:{color:W,bold:true,breakLine:false}},
  {text:x[1],options:{color:GO,hyperlink:{url:x[1]},breakLine:i<C.sources.length-1}}]),
  {isTextBox:true,margin:0,fontFace:F,x:.6,y:5.9,w:12.1,h:.8,fontSize:10.5,valign:"top"});
p.writeFile({fileName:out}).then(()=>console.log("ok",out));
